package Ejercicio4;

public class ConcretePrestamoFinanciamiento extends Builder{

	@Override
	public void buildCantidad() {
		prestamo.setCantidad(300);
		
	}

}
