package Ejercicio4;

public class Client {
	public static void main(String[] args) {
		
		Fondos.getInstance().getMonto();
		Thread threadCredito=new Thread(new Runnable() {
			@Override
			public void run(){
				Director director = new Director();
				ConcretePrestamoCredito credito = new ConcretePrestamoCredito();
				director.setProductoBuilder(credito);
				director.buildProduct();
				int cantidad = director.getPrestamo().getCantidad();
				Fondos.getInstance().prestamo(cantidad);
				System.out.println("Despues de prestamo Credito: ");
				Fondos.getInstance().getMonto();
				System.out.println();
			}
		});
		
		
		
		Thread threadFinanciamiento=new Thread(new Runnable() {
			@Override
			public void run(){
				Director director = new Director();
				ConcretePrestamoFinanciamiento financiamiento = new ConcretePrestamoFinanciamiento();
				director.setProductoBuilder(financiamiento);
				director.buildProduct();
				int cantidad = director.getPrestamo().getCantidad();
				Fondos.getInstance().prestamo(cantidad);
				System.out.println("Despues de prestamo Financiamiento: ");
				Fondos.getInstance().getMonto();
				System.out.println();
			}
		});
		
		Thread threadVivienda=new Thread(new Runnable() {
			@Override
			public void run(){
				Director director = new Director();
				ConcretePrestamoVivienda vivienda = new ConcretePrestamoVivienda();
				director.setProductoBuilder(vivienda);
				director.buildProduct();
				int cantidad = director.getPrestamo().getCantidad();
				Fondos.getInstance().prestamo(cantidad);		
				System.out.println("Despues de prestamo Vivienda: ");
				Fondos.getInstance().getMonto();	
				System.out.println();
			}
		});
		
		Thread threadNegocios=new Thread(new Runnable() {
			@Override
			public void run(){
				Director director = new Director();
				ConcretePrestamoNegocios negocios = new ConcretePrestamoNegocios();
				director.setProductoBuilder(negocios);
				director.buildProduct();
				int cantidad = director.getPrestamo().getCantidad();
				Fondos.getInstance().prestamo(cantidad);
				System.out.println("Despues de prestamo Negocios: ");
				Fondos.getInstance().getMonto();
			}
		});
		
		threadCredito.start();
		threadFinanciamiento.start();
		threadVivienda.start();
		threadNegocios.start();
		
	}
}


