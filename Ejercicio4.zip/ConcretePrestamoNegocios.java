package Ejercicio4;

public class ConcretePrestamoNegocios extends Builder{

	@Override
	public void buildCantidad() {
		prestamo.setCantidad(100);
		
	}

}
