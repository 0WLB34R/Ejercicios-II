package Ejercicio4;

public class Fondos {
	private static Fondos instance = null;
	private static int monto;
	
	private Fondos() {
		monto = 50000;
	}
	
	public static synchronized Fondos getInstance() {
		if(instance == null) {
			instance = new Fondos();
		}
		return instance;
	}
	
	public void prestamo(int cantidad) {
		monto = monto- cantidad;
	}
	
	public void getMonto() {
		System.out.println("Monto actual "+monto);
	}
}
