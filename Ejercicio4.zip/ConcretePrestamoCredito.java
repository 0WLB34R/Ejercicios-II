package Ejercicio4;

public class ConcretePrestamoCredito extends Builder{

	@Override
	public void buildCantidad() {
		prestamo.setCantidad(200);
		
	}

}
