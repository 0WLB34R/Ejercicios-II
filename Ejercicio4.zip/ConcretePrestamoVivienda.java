package Ejercicio4;

public class ConcretePrestamoVivienda extends Builder{

	@Override
	public void buildCantidad() {
		prestamo.setCantidad(400);
		
	}

}
