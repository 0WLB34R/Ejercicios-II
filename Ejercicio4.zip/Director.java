package Ejercicio4;

public class Director {
	private Builder builder;

	public Prestamo getPrestamo() {
		return builder.getPrestamo();
	}

	public void setProductoBuilder(Builder builder) {
		this.builder = builder;
	}

	public void buildProduct() {
		builder.createPrestamo();
		builder.buildCantidad();
	}
}
