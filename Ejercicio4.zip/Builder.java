package Ejercicio4;

public abstract class Builder {

	protected Prestamo prestamo;

	public Prestamo getPrestamo() {
		return prestamo;
	}

	public void createPrestamo() {
		prestamo = new Prestamo();
	}

	public abstract void buildCantidad();
}
