package Ejercicio3;

public class TerminalExpressionDef extends AbstractExpression{
	@Override
	public void interpreter(Context context, int i) {
	
			context.output = context.output+" "+context.input[i]+" ";
		
	}
}
