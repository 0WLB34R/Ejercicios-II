package Ejercicio3;

public class Client {
	public static void main(String [] args) {
		String msg = "Como: Dev, Quiero: Acceder al sistema, Para: Acceder a mi cuenta";
		System.out.println(new Parser(msg). evaluate());
	}
}
