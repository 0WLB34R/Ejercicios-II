package Ejercicio3;

public class Context {
	
protected String[] input;
	
	protected String output = "";

	public Context(String[] input) {
		this.input = input;
	}
	
}
