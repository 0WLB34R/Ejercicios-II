package Ejercicio3;

public class TerminalExpressionComo extends AbstractExpression{
	@Override
	public void interpreter(Context context, int i) {
		if (context.input[i].equals("Como:")) {
			context.output = context.output+"Given: ";
		}
		
	}
}
