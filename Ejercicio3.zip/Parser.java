package Ejercicio3;

import java.util.ArrayList;

public class Parser {

	private ArrayList<AbstractExpression> parseTree = new ArrayList<>();
	private Context context;
	
	public Parser(String s) {
		String[] parts = s.split(" ");
		context = new Context(parts);
		for (String token : parts) {
			
			switch (token) {
			case "Como:":
				parseTree.add(new TerminalExpressionComo());
				break;
			case "Quiero:":
				parseTree.add(new TerminalExpressionQuiero());
				break;
			case "Para:":
				parseTree.add(new TerminalExpressionPara());
				break;
			default:
				parseTree.add(new TerminalExpressionDef());
				break;
			}
		}
	}
	
	public String evaluate() {
		int i=0;
		for (AbstractExpression e : parseTree) {
			e.interpreter(context,i);
			i++;
		}
		return context.output;
	}
}
