package Ejercicio3;

public class TerminalExpressionPara extends AbstractExpression{
	@Override
	public void interpreter(Context context, int i) {
		
		if (context.input[i].equals("Para:")) {
			context.output = context.output+"Then: ";
		}
		
	}
}
