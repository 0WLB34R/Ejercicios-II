package Ejercicio3;

public class TerminalExpressionQuiero extends AbstractExpression{
	@Override
	public void interpreter(Context context, int i) {
		
		if (context.input[i].equals("Quiero:")) {
			context.output = context.output+"When: ";
		}
		
	}
}
