package Ejercicio3;

public abstract class AbstractExpression {
	public abstract void interpreter(Context context, int i);
}
